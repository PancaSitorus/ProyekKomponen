﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTS.Web.Helpers {

    public enum NeoSpeechVoiceType {
        Paul, Kate, Julie
    }

    //public struct NeoSpeechVoiceTypePaul {
    //    public override string ToString() {
    //        return "TTS_PAUL_DB";
    //    }
    //}

}