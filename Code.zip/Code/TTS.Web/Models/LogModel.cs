﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TTS.Web.Models {
    public class LogModel {

        public List<string> SpeechRequests { get; set; }

    }
}